package com.gamehub.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Controles en pantalla. Solo captura toques que caen sobre un control;
 * el resto pasa al juego. Cada control simula una tecla (onKey).
 */
class TouchControlsView(
    context: Context,
    private val buttons: List<TouchButton>,
    opacity: Float,
    private val onKey: (KeyDef, Boolean) -> Unit,
) : View(context) {

    private val d = resources.displayMetrics.density
    private val a = (opacity.coerceIn(0.15f, 1f) * 255).toInt()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val down = HashSet<KeyDef>()

    private fun dirKeys(b: TouchButton): List<KeyDef> =
        (if (b.key == "wasd") listOf("w", "s", "a", "d") else listOf("up", "down", "left", "right")).map { Keys.find(it) }

    /** true si (x,y) cae sobre el control; agrega a [out] las teclas que quedan presionadas. */
    private fun collect(b: TouchButton, x: Float, y: Float, out: MutableSet<KeyDef>): Boolean {
        val cx = b.x * width
        val cy = b.y * height
        val r = b.size * d / 2f
        val dx = x - cx
        val dy = y - cy
        if (b.kind == 0) {
            if (dx * dx + dy * dy > (r * 1.15f) * (r * 1.15f)) return false
            val dead = r * 0.28f
            val ax = abs(dx)
            val ay = abs(dy)
            val k = dirKeys(b)
            if (ay > dead && ay >= ax * 0.45f) out.add(if (dy < 0) k[0] else k[1])
            if (ax > dead && ax >= ay * 0.45f) out.add(if (dx < 0) k[2] else k[3])
            return true
        }
        if (dx * dx + dy * dy > (r * 1.2f) * (r * 1.2f)) return false
        out.add(Keys.find(b.key))
        return true
    }

    private fun hitsAny(x: Float, y: Float): Boolean {
        val tmp = HashSet<KeyDef>()
        return buttons.any { collect(it, x, y, tmp) }
    }

    private fun releaseAll() {
        for (k in down.toList()) onKey(k, false)
        down.clear()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (!hitsAny(e.x, e.y)) return false
            MotionEvent.ACTION_CANCEL -> { releaseAll(); return true }
        }
        val skip = when (e.actionMasked) {
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> e.actionIndex
            else -> -1
        }
        val want = HashSet<KeyDef>()
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            for (b in buttons) collect(b, e.getX(i), e.getY(i), want)
        }
        for (k in down.toList()) if (k !in want) { down.remove(k); onKey(k, false) }
        for (k in want) if (down.add(k)) {
            onKey(k, true)
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        invalidate()
        return true
    }

    override fun onDetachedFromWindow() {
        releaseAll()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        for (b in buttons) {
            val cx = b.x * width
            val cy = b.y * height
            val r = b.size * d / 2f
            if (b.kind == 0) {
                val w = r * 0.62f
                val k = dirKeys(b)
                arm(c, RectF(cx - w / 2, cy - r, cx + w / 2, cy), k[0] in down, w)
                arm(c, RectF(cx - w / 2, cy, cx + w / 2, cy + r), k[1] in down, w)
                arm(c, RectF(cx - r, cy - w / 2, cx, cy + w / 2), k[2] in down, w)
                arm(c, RectF(cx, cy - w / 2, cx + r, cy + w / 2), k[3] in down, w)
            } else {
                val pressed = Keys.find(b.key) in down
                fill.alpha = (a * (if (pressed) 0.6f else 0.2f)).toInt()
                c.drawCircle(cx, cy, r, fill)
                line.alpha = a
                c.drawCircle(cx, cy, r, line)
                txt.alpha = a
                val len = max(1, b.label.length)
                txt.textSize = r * 2f * min(0.42f, 1.1f / len)
                c.drawText(b.label, cx, cy - (txt.ascent() + txt.descent()) / 2f, txt)
            }
        }
    }

    private fun arm(c: Canvas, rc: RectF, pressed: Boolean, w: Float) {
        fill.alpha = (a * (if (pressed) 0.6f else 0.2f)).toInt()
        c.drawRoundRect(rc, w * 0.25f, w * 0.25f, fill)
        line.alpha = a
        c.drawRoundRect(rc, w * 0.25f, w * 0.25f, line)
    }
}
