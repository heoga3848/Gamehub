package com.gamehub.app

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Guarda el error si la app se cierra, para mostrarlo en el siguiente arranque. */
class GameHubApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("Hilo: ${t.name}\n$sw")
            }
            prev?.uncaughtException(t, e)
        }
    }
}
