package com.gamehub.app

import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import com.gamehub.app.ui.GameHubScreen
import com.gamehub.app.ui.resolveDark

class MainActivity : ComponentActivity() {
    private val vm: GameHubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val crash = File(filesDir, "crash.txt")
        if (crash.isFile) { showCrash(crash); return }

        val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            vm.importUris(uris)
        }

        val exporter = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            val g = vm.pending
            vm.pending = null
            if (uri != null && g != null) vm.exportGame(g, uri)
        }
        val iconPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val g = vm.pending
            vm.pending = null
            if (uri != null && g != null) vm.setIcon(g, uri)
        }

        setContent {
            val dark = resolveDark(vm.settings.theme)
            DisposableEffect(dark) {
                val t = Color.TRANSPARENT
                val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            GameHubScreen(
                vm = vm,
                onPlay = { game -> startActivity(GameActivity.intent(this@MainActivity, game.dir.name)) },
                onImport = { picker.launch(arrayOf("*/*")) },
                onExport = { g -> vm.pending = g; exporter.launch(g.name + ".zip") },
                onPickIcon = { g -> vm.pending = g; iconPicker.launch(arrayOf("image/*")) },
            )
        }
    }

    private fun showCrash(f: File) {
        val tv = TextView(this).apply {
            text = "GameHub se cerro por un error.\nMandame una captura de este texto:\n\n" + f.readText().take(6000)
            textSize = 11f
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            setPadding(32, 120, 32, 32)
        }
        val btn = Button(this).apply {
            text = "Borrar error y reintentar"
            setOnClickListener { f.delete(); recreate() }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(ScrollView(this@MainActivity).apply { addView(tv) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(btn)
        }
        setContentView(col)
    }
}
