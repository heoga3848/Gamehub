package com.gamehub.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Properties
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ImportException(message: String) : Exception(message)

class GameRepository(private val context: Context) {

    /** /data/data/<app>/files/juegos/ */
    val root: File
        get() = File(context.filesDir, "juegos").also { it.mkdirs() }

    // Orden de busqueda de portada pedido: cover.png, cover.jpg, icon.png, icon.jpg, thumbnail.png
    private val coverNames = listOf("custom_icon.png", "cover.png", "cover.jpg", "icon.png", "icon.jpg", "thumbnail.png")

    fun list(): List<Game> {
        val dirs = root.listFiles() ?: return emptyList()
        dirs.filter { it.name.startsWith(".tmp_") }.forEach { it.deleteRecursively() }
        return dirs.filter { it.isDirectory && !it.name.startsWith(".") }.map { toGame(it) }
    }

    fun toGame(dir: File): Game {
        val idFile = File(dir, ".gamehub_id")
        val installed = idFile.lastModified().takeIf { it > 0 } ?: dir.lastModified()
        return Game(
            id = dir.name,
            name = dir.name,
            dir = dir,
            cover = findCover(dir),
            sizeBytes = dirSize(dir),
            installedAt = installed,
            category = categoryOf(dir),
            entry = entryOf(dir) ?: "index.html",
        )
    }

    private fun findCover(dir: File): File? {
        val byLower = dir.listFiles()?.filter { it.isFile }?.associateBy { it.name.lowercase() } ?: return null
        for (n in coverNames) byLower[n]?.let { return it }
        return null
    }

    private fun dirSize(dir: File): Long =
        dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Id estable por juego (para aislar localStorage entre juegos, aunque se renombre). */
    fun gameKey(dir: File): String {
        val f = File(dir, ".gamehub_id")
        if (f.isFile) {
            val t = runCatching { f.readText().trim() }.getOrDefault("")
            if (t.isNotEmpty()) return t
        }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        runCatching { f.writeText(id) }
        return id
    }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun sanitize(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "").trim().trimStart('.').trim().take(60)

    private fun uniqueName(base: String): String {
        var name = base
        var i = 2
        while (File(root, name).exists()) { name = "$base-$i"; i++ }
        return name
    }

    /** Descomprime con java.util.zip en files/juegos/<nombre>/ */
    fun importZip(uri: Uri): Game {
        val raw = displayName(uri) ?: "juego"
        val base = sanitize(raw.replace(Regex("\\.zip$", RegexOption.IGNORE_CASE), "")).ifEmpty { "juego" }
        val tmp = File(root, ".tmp_${System.nanoTime()}")
        try {
            tmp.mkdirs()
            val tmpCanon = tmp.canonicalPath
            var count = 0
            val input = context.contentResolver.openInputStream(uri)
                ?: throw ImportException("No se pudo abrir el archivo")
            input.use { raw0 ->
                ZipInputStream(BufferedInputStream(raw0)).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    var e = zis.nextEntry
                    while (e != null) {
                        val name = e.name.replace('\\', '/')
                        if (!name.startsWith("__MACOSX/") && !name.endsWith(".DS_Store")) {
                            val out = File(tmp, name)
                            val canon = out.canonicalPath
                            if (canon != tmpCanon) {
                                if (!canon.startsWith(tmpCanon + File.separator)) {
                                    throw ImportException("Zip no valido (ruta insegura)")
                                }
                                if (e.isDirectory) {
                                    out.mkdirs()
                                } else {
                                    out.parentFile?.mkdirs()
                                    FileOutputStream(out).use { os ->
                                        while (true) {
                                            val n = zis.read(buf)
                                            if (n == -1) break
                                            os.write(buf, 0, n)
                                        }
                                    }
                                    count++
                                }
                            }
                        }
                        zis.closeEntry()
                        e = zis.nextEntry
                    }
                }
            }
            if (count == 0) throw ImportException("El archivo no es un .zip valido o esta vacio")

            // Se tolera una unica carpeta contenedora
            var gameRoot = tmp
            val kids = tmp.listFiles()?.toList() ?: emptyList()
            if (kids.size == 1 && kids[0].isDirectory) gameRoot = kids[0]
            val entry = entryOf(gameRoot) ?: throw ImportException("Este zip no tiene ningun archivo .html")

            val dest = File(root, uniqueName(base))
            if (!gameRoot.renameTo(dest)) throw ImportException("No se pudo guardar el juego")
            if (gameRoot != tmp) tmp.deleteRecursively()
            val p = readMeta(dest)
            p.setProperty("entry", entry)
            writeMeta(dest, p)
            gameKey(dest)
            return toGame(dest)
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            throw if (t is ImportException) t else ImportException(t.message ?: "Error al importar")
        }
    }

    // ---------- Importar .html suelto o .zip ----------
    private fun isHtmlName(n: String) = n.matches(Regex(".*\\.html?$", RegexOption.IGNORE_CASE))

    fun importUri(uri: Uri): Game {
        val raw = displayName(uri) ?: "juego"
        val isHtml = isHtmlName(raw) || context.contentResolver.getType(uri)?.startsWith("text/html") == true
        return if (isHtml) importHtml(uri, raw) else importZip(uri)
    }

    private fun importHtml(uri: Uri, raw: String): Game {
        var fileName = sanitize(raw).ifEmpty { "juego.html" }
        if (!isHtmlName(fileName)) fileName += ".html"
        val base = sanitize(raw.replace(Regex("\\.html?$", RegexOption.IGNORE_CASE), "")).ifEmpty { "juego" }
        val tmp = File(root, ".tmp_${System.nanoTime()}")
        try {
            tmp.mkdirs()
            val input = context.contentResolver.openInputStream(uri)
                ?: throw ImportException("No se pudo abrir el archivo")
            input.use { i -> FileOutputStream(File(tmp, fileName)).use { o -> i.copyTo(o) } }
            val dest = File(root, uniqueName(base))
            if (!tmp.renameTo(dest)) throw ImportException("No se pudo guardar el juego")
            val p = Properties()
            p.setProperty("entry", fileName)
            writeMeta(dest, p)
            gameKey(dest)
            return toGame(dest)
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            throw if (t is ImportException) t else ImportException(t.message ?: "Error al importar")
        }
    }

    // ---------- Metadata por juego (.gamehub_meta): categoria y archivo de entrada ----------
    private fun readMeta(dir: File): Properties {
        val p = Properties()
        runCatching { File(dir, META).inputStream().use { p.load(it) } }
        return p
    }

    private fun writeMeta(dir: File, p: Properties) {
        runCatching { File(dir, META).outputStream().use { p.store(it, null) } }
    }

    fun categoryOf(dir: File): String =
        readMeta(dir).getProperty("category")?.takeIf { it in CATEGORIES } ?: "Otros"

    /** Archivo .html que se abre: el guardado, si no index.html, si no el primer .html que haya. */
    fun entryOf(dir: File): String? {
        val saved = readMeta(dir).getProperty("entry")
        if (saved != null && !saved.contains("..") && File(dir, saved).isFile) return saved
        return findEntry(dir)
    }

    private fun findEntry(dir: File): String? {
        fun rel(f: File) = f.relativeTo(dir).path.replace(File.separatorChar, '/')
        return dir.walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in setOf("html", "htm") }
            .map { rel(it) }
            .sortedWith(
                compareBy<String>(
                    { it.count { c -> c == '/' } },
                    { !it.substringAfterLast('/').equals("index.html", true) },
                    { it },
                )
            )
            .firstOrNull()
    }

    fun setCategory(game: Game, cat: String): Game {
        val p = readMeta(game.dir)
        p.setProperty("category", cat)
        writeMeta(game.dir, p)
        return game.copy(category = cat)
    }

    fun setIcon(game: Game, uri: Uri): Game {
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: throw ImportException("No se pudo leer la imagen")
        val scale = minOf(1f, 512f / maxOf(bmp.width, bmp.height).toFloat())
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true,
            )
        } else bmp
        File(game.dir, ICON).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return toGame(game.dir)
    }

    /** Guarda el juego como .zip (sin el id interno, para que al reimportar sea independiente). */
    fun exportZip(game: Game, uri: Uri) {
        val os = context.contentResolver.openOutputStream(uri)
            ?: throw ImportException("No se pudo crear el archivo")
        ZipOutputStream(BufferedOutputStream(os)).use { zos ->
            game.dir.walkTopDown().filter { it.isFile && it.name != ".gamehub_id" }.forEach { f ->
                zos.putNextEntry(ZipEntry(f.relativeTo(game.dir).path.replace(File.separatorChar, '/')))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    fun rename(game: Game, raw: String): Result<Game> = runCatching {
        val name = sanitize(raw)
        if (name.isEmpty()) throw ImportException("Nombre no valido")
        if (name == game.name) return@runCatching game
        val clash = root.listFiles()?.any { it.name.equals(name, true) && it.name != game.name } == true
        if (clash) throw ImportException("Ya existe un juego con ese nombre")
        val dest = File(root, name)
        if (!game.dir.renameTo(dest)) throw ImportException("No se pudo renombrar")
        game.copy(
            id = name, name = name, dir = dest,
            cover = game.cover?.let { File(dest, it.name) },
        )
    }

    fun delete(game: Game): Boolean = game.dir.deleteRecursively()

    companion object {
        const val META = ".gamehub_meta"
        const val ICON = "custom_icon.png"
    }
}
