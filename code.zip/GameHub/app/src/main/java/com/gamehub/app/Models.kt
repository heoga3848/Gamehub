package com.gamehub.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

data class Game(
    val id: String,          // nombre de la carpeta en files/juegos/
    val name: String,
    val dir: File,
    val cover: File?,        // portada leida del zip (cover/icon/thumbnail)
    val sizeBytes: Long,
    val installedAt: Long,
    val category: String = "Otros",
    val entry: String = "index.html",
) {
    val sizeLabel: String get() = formatSize(sizeBytes)
}

fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (bytes > 0 && mb < 0.1) "<0.1 MB" else String.format(Locale.US, "%.1f MB", mb)
}

data class AppSettings(
    val liquidGlass: Boolean = true,
    val blurDp: Float = 24f,
    val theme: Int = 0,          // 0 sistema, 1 claro, 2 oscuro
    val accentIndex: Int = 0,
    val columns: Int = 2,
    val sort: Int = 0,           // 0 nombre, 1 recientes, 2 peso
    val showSize: Boolean = true,
    val orientation: Int = 0,    // 0 auto, 1 horizontal, 2 vertical
    val immersive: Boolean = true,
    val keepScreenOn: Boolean = true,
    val touchEnabled: Boolean = false,
    val touchOpacity: Float = 0.6f,
    val touchButtons: List<TouchButton> = defaultTouchButtons(),
)

val CATEGORIES = listOf("Plataforma", "Puzzle", "Arcade", "Retro", "Otros")

/** kind 0 = D-Pad (key = "arrows" | "wasd"), kind 1 = boton (key = id de Keys). x/y = fraccion de pantalla, size en dp. */
data class TouchButton(
    val id: String, val kind: Int, val label: String, val key: String,
    val x: Float, val y: Float, val size: Float,
)

fun defaultTouchButtons() = listOf(
    TouchButton("dpad", 0, "D-Pad", "arrows", 0.14f, 0.66f, 150f),
    TouchButton("a", 1, "A", "x", 0.92f, 0.60f, 64f),
    TouchButton("b", 1, "B", "z", 0.82f, 0.78f, 64f),
    TouchButton("select", 1, "Select", "shift", 0.40f, 0.90f, 60f),
    TouchButton("start", 1, "Start", "enter", 0.60f, 0.90f, 60f),
)

fun touchToJson(l: List<TouchButton>): String = JSONArray().also { arr ->
    l.forEach {
        arr.put(JSONObject().put("id", it.id).put("kind", it.kind).put("label", it.label).put("key", it.key)
            .put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("size", it.size.toDouble()))
    }
}.toString()

fun touchFromJson(s: String?): List<TouchButton> {
    if (s == null) return defaultTouchButtons()
    return runCatching {
        val a = JSONArray(s)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            TouchButton(
                o.getString("id"), o.getInt("kind"), o.getString("label"), o.getString("key"),
                o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getDouble("size").toFloat(),
            )
        }
    }.getOrNull()?.takeIf { it.isNotEmpty() } ?: defaultTouchButtons()
}
