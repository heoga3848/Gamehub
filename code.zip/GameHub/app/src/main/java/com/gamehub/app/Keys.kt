package com.gamehub.app

import android.view.KeyEvent

/** Tecla que puede simular un boton tactil. */
data class KeyDef(val id: String, val label: String, val code: Int, val meta: Int = 0)

object Keys {
    val all: List<KeyDef> = buildList {
        add(KeyDef("up", "Flecha \u2191", KeyEvent.KEYCODE_DPAD_UP))
        add(KeyDef("down", "Flecha \u2193", KeyEvent.KEYCODE_DPAD_DOWN))
        add(KeyDef("left", "Flecha \u2190", KeyEvent.KEYCODE_DPAD_LEFT))
        add(KeyDef("right", "Flecha \u2192", KeyEvent.KEYCODE_DPAD_RIGHT))
        add(KeyDef("space", "Espacio", KeyEvent.KEYCODE_SPACE))
        add(KeyDef("enter", "Enter", KeyEvent.KEYCODE_ENTER))
        add(KeyDef("shift", "Shift", KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON))
        add(KeyDef("ctrl", "Ctrl", KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON))
        add(KeyDef("alt", "Alt", KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON))
        add(KeyDef("esc", "Esc", KeyEvent.KEYCODE_ESCAPE))
        add(KeyDef("tab", "Tab", KeyEvent.KEYCODE_TAB))
        add(KeyDef("backspace", "Retroceso", KeyEvent.KEYCODE_DEL))
        for (c in 'a'..'z') add(KeyDef(c.toString(), c.uppercaseChar().toString(), KeyEvent.KEYCODE_A + (c - 'a')))
        for (c in '0'..'9') add(KeyDef(c.toString(), c.toString(), KeyEvent.KEYCODE_0 + (c - '0')))
    }

    private val byId = all.associateBy { it.id }

    fun find(id: String): KeyDef = byId[id] ?: all.first()
}
