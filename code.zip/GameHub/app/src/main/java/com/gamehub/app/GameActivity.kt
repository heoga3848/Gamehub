package com.gamehub.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.SystemClock
import android.view.KeyEvent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JsResult
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream

/**
 * Corre un juego HTML5 en pantalla completa.
 * Los archivos se sirven desde https://g<id>.gamehub.local/ (interceptado, sin red), asi:
 *  - fetch/XHR/WebGL/audio/modulos ES funcionan como en un servidor real
 *  - cada juego tiene su propio origen => su propio localStorage/IndexedDB
 */
class GameActivity : ComponentActivity() {
    private var webView: WebView? = null
    private var immersive = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val name = intent.getStringExtra(EXTRA)
        if (name == null) { finish(); return }
        val repo = GameRepository(this)
        val dir = File(repo.root, name)
        val entry = repo.entryOf(dir)
        if (entry == null) {
            Toast.makeText(this, "Este juego no tiene ningun archivo .html", Toast.LENGTH_LONG).show()
            finish(); return
        }
        val s = Prefs(this).load()
        immersive = s.immersive
        val host = "g${repo.gameKey(dir)}.gamehub.local"

        requestedOrientation = when (s.orientation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (s.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, !immersive)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val wv = WebView(this)
        webView = wv
        setupWebView(wv, dir, host)
        root.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (s.touchEnabled) {
            val tc = TouchControlsView(this, s.touchButtons, s.touchOpacity) { k, isDown -> sendKey(k, isDown) }
            root.addView(tc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // Boton para salir (esquina superior izquierda, semitransparente)
        val btn = TextView(this).apply {
            text = "\u2715"
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            alpha = 0.55f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x66000000) }
            setOnClickListener { finish() }
        }
        val lp = FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.START).apply {
            setMargins(dp(12), dp(12), 0, 0)
        }
        root.addView(btn, lp)
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            lp.setMargins(dp(12) + i.left, dp(12) + i.top, 0, 0)
            btn.layoutParams = lp
            insets
        }

        setContentView(root)
        if (immersive) hideBars()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { confirmExit() }
        })

        wv.requestFocus()
        wv.loadUrl("https://$host/" + entry.split('/').joinToString("/") { Uri.encode(it) })
    }

    /** Simula una tecla del teclado en el WebView (llega al juego como keydown/keyup). */
    private fun sendKey(k: KeyDef, down: Boolean) {
        val wv = webView ?: return
        val t = SystemClock.uptimeMillis()
        wv.dispatchKeyEvent(KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, k.code, 0, if (down) k.meta else 0))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun setupWebView(wv: WebView, gameDir: File, host: String) {
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage / sessionStorage / IndexedDB
            @Suppress("DEPRECATION") databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false   // audio sin gesto previo
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            textZoom = 100
        }
        wv.setBackgroundColor(Color.BLACK)
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false

        val rootCanon = gameDir.canonicalPath
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val req = request ?: return null
                if (req.url.host != host) return null
                return serve(rootCanon, req)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // No salir del juego hacia sitios externos
                return request?.url?.host != host
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@GameActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@GameActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result?.confirm() }
                    .setNegativeButton("Cancelar") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }
    }

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))
    )

    private fun serve(rootCanon: String, req: WebResourceRequest): WebResourceResponse {
        return try {
            var rel = req.url.path ?: "/"
            if (rel.endsWith("/")) rel += "index.html"
            val file = File(rootCanon, rel).canonicalFile
            if (!file.path.startsWith(rootCanon + File.separator) || !file.isFile) return notFound()

            val mime = mimeOf(file.name)
            val enc = if (mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") || mime.contains("javascript")) "utf-8" else null
            val len = file.length()
            val headers = mutableMapOf(
                "Access-Control-Allow-Origin" to "*",
                "Accept-Ranges" to "bytes",
                "Cache-Control" to "no-cache",
            )

            val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
            if (range != null && range.startsWith("bytes=")) {
                val spec = range.removePrefix("bytes=").substringBefore(",").trim()
                val a = spec.substringBefore("-")
                val b = spec.substringAfter("-", "")
                val start: Long
                val end: Long
                if (a.isEmpty()) {
                    val n = b.toLongOrNull() ?: 0L
                    start = maxOf(0L, len - n); end = len - 1
                } else {
                    start = a.toLongOrNull() ?: 0L
                    end = if (b.isEmpty()) len - 1 else minOf(b.toLongOrNull() ?: (len - 1), len - 1)
                }
                if (start >= len || start > end) {
                    headers["Content-Range"] = "bytes */$len"
                    return WebResourceResponse(mime, enc, 416, "Range Not Satisfiable", headers, ByteArrayInputStream(ByteArray(0)))
                }
                val fis = FileInputStream(file)
                fis.channel.position(start)
                headers["Content-Range"] = "bytes $start-$end/$len"
                headers["Content-Length"] = (end - start + 1).toString()
                WebResourceResponse(mime, enc, 206, "Partial Content", headers, LimitedInputStream(fis, end - start + 1))
            } else {
                headers["Content-Length"] = len.toString()
                WebResourceResponse(mime, enc, 200, "OK", headers, FileInputStream(file))
            }
        } catch (e: Exception) {
            notFound()
        }
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MIME[ext] ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun hideBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && immersive) hideBars()
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle("Salir del juego")
            .setMessage("\u00BFVolver a la biblioteca?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Seguir jugando", null)
            .show()
    }

    override fun onPause() { webView?.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); webView?.onResume() }
    override fun onDestroy() {
        webView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        webView = null
        super.onDestroy()
    }

    private class LimitedInputStream(input: InputStream, private var left: Long) : FilterInputStream(input) {
        override fun read(): Int {
            if (left <= 0) return -1
            val r = super.read()
            if (r >= 0) left--
            return r
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = super.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
    }

    companion object {
        private const val EXTRA = "game"
        fun intent(ctx: Context, folder: String): Intent =
            Intent(ctx, GameActivity::class.java).putExtra(EXTRA, folder)

        private val MIME = mapOf(
            "html" to "text/html", "htm" to "text/html", "js" to "text/javascript", "mjs" to "text/javascript",
            "css" to "text/css", "json" to "application/json", "map" to "application/json",
            "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "gif" to "image/gif",
            "webp" to "image/webp", "svg" to "image/svg+xml", "ico" to "image/x-icon", "avif" to "image/avif",
            "bmp" to "image/bmp", "mp3" to "audio/mpeg", "ogg" to "audio/ogg", "oga" to "audio/ogg",
            "wav" to "audio/wav", "m4a" to "audio/mp4", "aac" to "audio/aac", "flac" to "audio/flac",
            "mp4" to "video/mp4", "webm" to "video/webm", "ogv" to "video/ogg",
            "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf", "otf" to "font/otf",
            "wasm" to "application/wasm", "txt" to "text/plain", "xml" to "application/xml",
            "glb" to "model/gltf-binary", "gltf" to "model/gltf+json",
        )
    }
}
