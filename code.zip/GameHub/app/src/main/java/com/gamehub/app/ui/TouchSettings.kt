package com.gamehub.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gamehub.app.GameHubViewModel
import com.gamehub.app.Keys
import com.gamehub.app.TouchButton
import com.gamehub.app.defaultTouchButtons
import kotlin.math.roundToInt

private fun GameHubViewModel.editButton(id: String, f: (TouchButton) -> TouchButton) =
    updateSettings { st -> st.copy(touchButtons = st.touchButtons.map { if (it.id == id) f(it) else it }) }

@Composable
fun TouchControlsSettings(vm: GameHubViewModel) {
    val g = LocalGlass.current
    val ink = g.ink
    val s = vm.settings

    SectionTitle("Controles t\u00E1ctiles")
    SwitchRow("Mostrar controles al jugar", "Botones en pantalla que simulan teclas del teclado.", s.touchEnabled) { v ->
        vm.updateSettings { it.copy(touchEnabled = v) }
    }
    LabelText("Transparencia: ${(s.touchOpacity * 100).toInt()}%")
    Slider(
        value = s.touchOpacity, valueRange = 0.15f..1f,
        onValueChange = { v -> vm.updateSettings { it.copy(touchOpacity = v) } },
        colors = SliderDefaults.colors(thumbColor = g.accent, activeTrackColor = g.accent),
    )

    Text("Arrastra cada control para moverlo (vista previa horizontal).", color = ink.copy(alpha = 0.6f), fontSize = 12.sp)
    Spacer(Modifier.height(8.dp))
    BoxWithConstraints(
        Modifier.fillMaxWidth().aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.Black.copy(alpha = 0.35f))
            .border(1.dp, ink.copy(alpha = 0.2f), RoundedCornerShape(18.dp)),
    ) {
        val pw = constraints.maxWidth.toFloat()
        val ph = constraints.maxHeight.toFloat()
        val scale = maxWidth / 800.dp
        s.touchButtons.forEach { b -> key(b.id) { DragButton(b, pw, ph, scale, vm) } }
    }

    s.touchButtons.forEach { b ->
        key(b.id) {
            Column(
                Modifier.fillMaxWidth().padding(top = 10.dp)
                    .clip(RoundedCornerShape(18.dp)).background(ink.copy(alpha = 0.06f)).padding(12.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (b.kind == 0) "D-Pad" else "Bot\u00F3n ${b.label}",
                        color = ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f),
                    )
                    if (b.kind == 1) {
                        Icon(
                            Icons.Rounded.Delete, "Quitar", tint = Color(0xFFFF453A),
                            modifier = Modifier.size(30.dp).clip(CircleShape).consumeClicks {
                                vm.updateSettings { st -> st.copy(touchButtons = st.touchButtons.filter { it.id != b.id }) }
                            },
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (b.kind == 0) {
                    Segmented(listOf("Flechas", "WASD"), if (b.key == "wasd") 1 else 0) { i ->
                        vm.editButton(b.id) { it.copy(key = if (i == 1) "wasd" else "arrows") }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = b.label,
                            onValueChange = { v -> vm.editButton(b.id) { it.copy(label = v.take(6)) } },
                            singleLine = true, label = { Text("Texto") }, modifier = Modifier.weight(1f),
                        )
                        KeyPicker(b.key) { id -> vm.editButton(b.id) { it.copy(key = id) } }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Tama\u00F1o: ${b.size.toInt()}", color = ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Slider(
                    value = b.size, valueRange = if (b.kind == 0) 100f..260f else 36f..130f,
                    onValueChange = { v -> vm.editButton(b.id) { it.copy(size = v) } },
                    colors = SliderDefaults.colors(thumbColor = g.accent, activeTrackColor = g.accent),
                )
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Pill("Agregar bot\u00F3n") {
            if (s.touchButtons.size < 14) {
                vm.updateSettings { st ->
                    st.copy(touchButtons = st.touchButtons + TouchButton("b" + System.currentTimeMillis(), 1, "E", "e", 0.5f, 0.5f, 64f))
                }
            }
        }
        Pill("Restablecer") { vm.updateSettings { it.copy(touchButtons = defaultTouchButtons()) } }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        Modifier.clip(CircleShape).background(g.accent.copy(alpha = 0.2f)).consumeClicks(onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    ) { Text(text, color = g.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable
private fun KeyPicker(current: String, onPick: (String) -> Unit) {
    val g = LocalGlass.current
    var open by remember { mutableStateOf(false) }
    Box {
        Box(
            Modifier.clip(CircleShape).background(g.accent.copy(alpha = 0.2f)).consumeClicks { open = true }
                .padding(horizontal = 14.dp, vertical = 14.dp),
        ) {
            Text("Tecla: ${Keys.find(current).label} \u25BE", color = g.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Keys.all.forEach { k ->
                DropdownMenuItem(text = { Text(k.label) }, onClick = { onPick(k.id); open = false })
            }
        }
    }
}

@Composable
private fun DragButton(b: TouchButton, pw: Float, ph: Float, scale: Float, vm: GameHubViewModel) {
    val g = LocalGlass.current
    val sizeDp = (b.size * scale).dp
    val sizePx = with(LocalDensity.current) { sizeDp.toPx() }
    Box(
        Modifier
            .offset { IntOffset((b.x * pw - sizePx / 2f).roundToInt(), (b.y * ph - sizePx / 2f).roundToInt()) }
            .size(sizeDp)
            .clip(CircleShape)
            .background(g.accent.copy(alpha = 0.35f))
            .border(1.5.dp, g.accent, CircleShape)
            .pointerInput(b.id) {
                detectDragGestures { change, drag ->
                    change.consume()
                    vm.editButton(b.id) {
                        it.copy(
                            x = (it.x + drag.x / pw).coerceIn(0.03f, 0.97f),
                            y = (it.y + drag.y / ph).coerceIn(0.03f, 0.97f),
                        )
                    }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (b.kind == 0) "\u271B" else b.label, color = g.ink, fontWeight = FontWeight.Bold,
            fontSize = (b.size * scale * 0.32f).coerceIn(8f, 24f).sp, maxLines = 1,
        )
    }
}
