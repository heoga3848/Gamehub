package com.gamehub.app

import java.io.File
import java.util.Locale

data class Game(
    val id: String,          // nombre de la carpeta en files/juegos/
    val name: String,
    val dir: File,
    val cover: File?,        // portada leida del zip (cover/icon/thumbnail)
    val sizeBytes: Long,
    val installedAt: Long,
) {
    val sizeLabel: String get() = formatSize(sizeBytes)
}

fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (bytes > 0 && mb < 0.1) "<0.1 MB" else String.format(Locale.US, "%.1f MB", mb)
}

data class AppSettings(
    val liquidGlass: Boolean = true,
    val blurDp: Float = 24f,
    val theme: Int = 0,          // 0 sistema, 1 claro, 2 oscuro
    val accentIndex: Int = 0,
    val columns: Int = 2,
    val sort: Int = 0,           // 0 nombre, 1 recientes, 2 peso
    val showSize: Boolean = true,
    val orientation: Int = 0,    // 0 auto, 1 horizontal, 2 vertical
    val immersive: Boolean = true,
    val keepScreenOn: Boolean = true,
)
