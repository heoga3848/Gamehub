package com.gamehub.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.gamehub.app.Game
import com.gamehub.app.GameHubViewModel
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.haze
import kotlinx.coroutines.delay

@Composable
fun GameHubScreen(vm: GameHubViewModel, onPlay: (Game) -> Unit, onImport: () -> Unit) {
    val s = vm.settings
    val dark = resolveDark(s.theme)
    val accent = Accents[s.accentIndex.coerceIn(0, Accents.lastIndex)]
    val haze = remember { HazeState() }
    val spec = GlassSpec(s.liquidGlass, s.blurDp.dp, dark, accent, haze)
    GameHubTheme(dark, accent) {
        CompositionLocalProvider(LocalGlass provides spec) {
            ScreenBody(vm, onPlay, onImport)
        }
    }
}

@Composable
private fun ScreenBody(vm: GameHubViewModel, onPlay: (Game) -> Unit, onImport: () -> Unit) {
    val g = LocalGlass.current
    val s = vm.settings
    val ink = g.ink
    val bg = if (g.dark) Color.Black else Color(0xFFF2F2F7)
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    var showSettings by remember { mutableStateOf(false) }
    var menuGame by remember { mutableStateOf<Game?>(null) }
    var renameGame by remember { mutableStateOf<Game?>(null) }
    var deleteGame by remember { mutableStateOf<Game?>(null) }
    val list = vm.visibleGames()

    BackHandler(enabled = showSettings || menuGame != null) {
        if (menuGame != null) menuGame = null else showSettings = false
    }

    val emptyText = when {
        vm.query.isNotBlank() -> "Sin resultados para \u00AB${vm.query.trim()}\u00BB"
        vm.tab == 1 -> "No tienes favoritos todav\u00EDa, toca el coraz\u00F3n de un juego para agregarlo"
        else -> "Todav\u00EDa no hay juegos.\nToca + para importar un .zip"
    }

    Box(Modifier.fillMaxSize().background(bg)) {

        // ---- Contenido (fuente del blur) ----
        Box(Modifier.fillMaxSize().haze(state = g.haze)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(s.columns.coerceIn(1, 3)),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp,
                    top = topInset + 76.dp, bottom = bottomInset + 112.dp,
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item(key = "title", span = { GridItemSpan(maxLineSpan) }) {
                    Text(
                        if (vm.tab == 0) "GAMES" else "FAVORITES",
                        color = ink, fontSize = 46.sp, fontWeight = FontWeight.Black,
                        letterSpacing = (-1).sp, modifier = Modifier.padding(start = 2.dp, bottom = 2.dp),
                    )
                }
                if (list.isEmpty() && vm.loaded) {
                    item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                        Box(
                            Modifier.fillMaxWidth().padding(top = 120.dp, start = 12.dp, end = 12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                emptyText, color = ink.copy(alpha = 0.6f), fontSize = 16.sp,
                                textAlign = TextAlign.Center, lineHeight = 22.sp,
                            )
                        }
                    }
                }
                items(list, key = { it.id }) { game ->
                    GameCard(
                        game = game,
                        fav = game.id in vm.favorites,
                        showSize = s.showSize,
                        modifier = Modifier.animateItem(),
                        onPlay = { onPlay(game) },
                        onMenu = { menuGame = game },
                        onFav = { vm.toggleFavorite(game.id) },
                    )
                }
            }
        }

        // ---- Barra superior: ajustes | GAMES-FAVORITES | columnas ----
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth()
                .padding(top = topInset + 8.dp, start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            GlassIconButton(Icons.Rounded.Settings, "Ajustes", { showSettings = true })
            TabPill(vm.tab) { vm.tab = it }
            GlassIconButton(Icons.Rounded.GridView, "Columnas", {
                vm.updateSettings { st ->
                    st.copy(columns = when (st.columns) { 2 -> 3; 3 -> 1; else -> 2 })
                }
            })
        }

        // ---- Barra inferior: buscador | + importar ----
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .navigationBarsPadding().imePadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SearchPill(vm.query, { vm.query = it }, Modifier.weight(1f))
            GlassIconButton(Icons.Rounded.Add, "Importar juego .zip", onImport, size = 56.dp, tint = g.accent)
        }

        // ---- Aviso ----
        vm.message?.let { msg ->
            LaunchedEffect(msg) {
                delay(3200)
                if (vm.message == msg) vm.message = null
            }
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                    .padding(bottom = 92.dp, start = 24.dp, end = 24.dp)
                    .glass(RoundedCornerShape(22.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
            ) {
                Text(msg, color = ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            }
        }

        // ---- Ajustes ----
        AnimatedVisibility(
            visible = showSettings,
            enter = fadeIn() + slideInVertically { it / 3 },
            exit = fadeOut() + slideOutVertically { it / 3 },
        ) {
            SettingsOverlay(vm) { showSettings = false }
        }

        // ---- Menu de juego (mantener presionado) ----
        menuGame?.let { game ->
            GameActionsOverlay(
                game = game,
                onDismiss = { menuGame = null },
                onRename = { menuGame = null; renameGame = game },
                onDelete = { menuGame = null; deleteGame = game },
            )
        }

        // ---- Importando ----
        if (vm.busy) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).consumeClicks(),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    Modifier.glass(RoundedCornerShape(28.dp)).padding(horizontal = 32.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator(color = g.accent)
                    Spacer(Modifier.height(14.dp))
                    Text("Importando\u2026", color = ink, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // ---- Dialogos ----
    renameGame?.let { game ->
        var text by remember(game.id) { mutableStateOf(game.name) }
        var error by remember(game.id) { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { renameGame = null },
            title = { Text("Renombrar juego") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it; error = null },
                    singleLine = true, isError = error != null,
                    supportingText = { error?.let { Text(it) } },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = vm.rename(game, text)
                    if (err == null) renameGame = null else error = err
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { renameGame = null }) { Text("Cancelar") } },
        )
    }

    deleteGame?.let { game ->
        AlertDialog(
            onDismissRequest = { deleteGame = null },
            title = { Text("Borrar juego") },
            text = { Text("\u00BFBorrar \u00AB${game.name}\u00BB (${game.sizeLabel})? Se eliminan sus archivos.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(game); deleteGame = null }) {
                    Text("Borrar", color = Color(0xFFFF453A))
                }
            },
            dismissButton = { TextButton(onClick = { deleteGame = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun TabPill(selected: Int, onSelect: (Int) -> Unit) {
    val g = LocalGlass.current
    Row(Modifier.glass(CircleShape).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("GAMES", "FAVORITES").forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.clip(CircleShape)
                    .background(if (sel) g.accent.copy(alpha = 0.22f) else Color.Transparent)
                    .consumeClicks { onSelect(i) }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
            ) {
                Text(
                    label, maxLines = 1, fontSize = 14.sp, fontWeight = FontWeight.Black,
                    color = if (sel) g.accent else g.ink,
                )
            }
        }
    }
}

@Composable
private fun SearchPill(value: String, onChange: (String) -> Unit, modifier: Modifier) {
    val g = LocalGlass.current
    val focus = LocalFocusManager.current
    Row(
        modifier.height(56.dp)
            .glass(CircleShape, tint = Color(0xFFFF4D8D), tint2 = g.accent, strength = 0.42f)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, "Buscar", tint = g.ink.copy(alpha = 0.7f), modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = g.ink, fontSize = 17.sp, fontWeight = FontWeight.Bold),
            cursorBrush = SolidColor(g.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text("SEARCH", color = g.ink.copy(alpha = 0.5f), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    inner()
                }
            },
        )
        if (value.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, "Limpiar", tint = g.ink.copy(alpha = 0.7f),
                modifier = Modifier.size(22.dp).clip(CircleShape).consumeClicks { onChange("") },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GameCard(
    game: Game,
    fav: Boolean,
    showSize: Boolean,
    modifier: Modifier,
    onPlay: () -> Unit,
    onMenu: () -> Unit,
    onFav: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier.fillMaxWidth().aspectRatio(0.9f)
            .clip(shape)
            .background(Color(0xFF2A2A2E))
            .combinedClickable(
                onClick = onPlay,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onMenu()
                },
            ),
    ) {
        if (game.cover != null) {
            AsyncImage(
                model = game.cover, contentDescription = game.name,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(),
            )
        } else {
            val h = game.name.hashCode() and 0x7fffffff
            val hue = (h % 360).toFloat()
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(Color.hsv(hue, 0.55f, 0.75f), Color.hsv((hue + 40f) % 360f, 0.6f, 0.45f)))
                ),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    game.name.take(1).uppercase(), color = Color.White.copy(alpha = 0.85f),
                    fontSize = 56.sp, fontWeight = FontWeight.Black,
                )
            }
        }

        // Nombre + peso
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))))
                .padding(start = 14.dp, end = 14.dp, top = 30.dp, bottom = 12.dp),
        ) {
            Text(
                game.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            if (showSize) {
                Text(game.sizeLabel, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        }

        // Corazon
        Box(
            Modifier.align(Alignment.TopEnd).padding(8.dp).size(38.dp)
                .clip(CircleShape).background(Color.Black.copy(alpha = 0.38f))
                .clickable(onClick = onFav),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = "Favorito",
                tint = if (fav) Color(0xFFFF2D55) else Color.White,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

@Composable
private fun GameActionsOverlay(game: Game, onDismiss: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).consumeClicks(onDismiss)) {
        Column(
            Modifier.align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
                .fillMaxWidth()
                .glass(RoundedCornerShape(32.dp))
                .consumeClicks()
                .padding(20.dp),
        ) {
            Text(game.name, color = g.ink, fontSize = 20.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("${game.sizeLabel} en disco", color = g.ink.copy(alpha = 0.6f), fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            ActionRow(Icons.Rounded.Edit, "Renombrar", g.ink, onRename)
            ActionRow(Icons.Rounded.Delete, "Borrar", Color(0xFFFF453A), onDelete)
            ActionRow(Icons.Rounded.Close, "Cancelar", g.ink.copy(alpha = 0.7f), onDismiss)
        }
    }
}

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, tint = color)
        Spacer(Modifier.width(14.dp))
        Text(label, color = color, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}
