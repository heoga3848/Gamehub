package com.gamehub.app

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("gamehub", Context.MODE_PRIVATE)

    fun load() = AppSettings(
        liquidGlass = sp.getBoolean("glass", true),
        blurDp = sp.getFloat("blur", 24f),
        theme = sp.getInt("theme", 0),
        accentIndex = sp.getInt("accent", 0),
        columns = sp.getInt("columns", 2),
        sort = sp.getInt("sort", 0),
        showSize = sp.getBoolean("showSize", true),
        orientation = sp.getInt("orientation", 0),
        immersive = sp.getBoolean("immersive", true),
        keepScreenOn = sp.getBoolean("keepOn", true),
    )

    fun save(s: AppSettings) {
        sp.edit()
            .putBoolean("glass", s.liquidGlass)
            .putFloat("blur", s.blurDp)
            .putInt("theme", s.theme)
            .putInt("accent", s.accentIndex)
            .putInt("columns", s.columns)
            .putInt("sort", s.sort)
            .putBoolean("showSize", s.showSize)
            .putInt("orientation", s.orientation)
            .putBoolean("immersive", s.immersive)
            .putBoolean("keepOn", s.keepScreenOn)
            .apply()
    }

    fun favorites(): Set<String> = HashSet(sp.getStringSet("favs", emptySet()) ?: emptySet())

    fun saveFavorites(f: Set<String>) {
        sp.edit().putStringSet("favs", HashSet(f)).apply()
    }
}
