package com.gamehub.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameHubViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = GameRepository(app)
    private val prefs = Prefs(app)

    var settings by mutableStateOf(prefs.load()); private set
    var games by mutableStateOf<List<Game>>(emptyList()); private set
    var favorites by mutableStateOf(prefs.favorites()); private set
    var loaded by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set

    var tab by mutableIntStateOf(0)          // 0 = GAMES, 1 = FAVORITES
    var query by mutableStateOf("")
    var message by mutableStateOf<String?>(null)

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            games = withContext(Dispatchers.IO) { repo.list() }
            loaded = true
        }
    }

    fun updateSettings(block: (AppSettings) -> AppSettings) {
        settings = block(settings)
        prefs.save(settings)
    }

    fun visibleGames(): List<Game> {
        val q = query.trim()
        val base = if (tab == 1) games.filter { it.id in favorites } else games
        val filtered = if (q.isEmpty()) base else base.filter { it.name.contains(q, ignoreCase = true) }
        return when (settings.sort) {
            1 -> filtered.sortedByDescending { it.installedAt }
            2 -> filtered.sortedByDescending { it.sizeBytes }
            else -> filtered.sortedBy { it.name.lowercase() }
        }
    }

    private fun setFavorites(f: Set<String>) {
        favorites = f
        prefs.saveFavorites(f)
    }

    fun toggleFavorite(id: String) {
        setFavorites(if (id in favorites) favorites - id else favorites + id)
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            busy = true
            var ok = 0
            var lastName = ""
            var lastErr: String? = null
            for (u in uris) {
                val r = withContext(Dispatchers.IO) { runCatching { repo.importZip(u) } }
                if (r.isSuccess) {
                    ok++
                    lastName = r.getOrThrow().name
                } else {
                    lastErr = r.exceptionOrNull()?.message ?: "Error al importar"
                }
            }
            games = withContext(Dispatchers.IO) { repo.list() }
            busy = false
            val err = lastErr
            message = when {
                err == null -> if (ok == 1) "\u00AB$lastName\u00BB instalado" else "$ok juegos instalados"
                ok == 0 -> err
                else -> "$ok instalados \u00B7 error: $err"
            }
        }
    }

    /** Devuelve null si todo bien, o el mensaje de error. */
    fun rename(game: Game, newName: String): String? {
        val r = repo.rename(game, newName)
        val updated = r.getOrNull() ?: return r.exceptionOrNull()?.message ?: "No se pudo renombrar"
        games = games.map { if (it.id == game.id) updated else it }
        if (game.id in favorites && updated.id != game.id) setFavorites(favorites - game.id + updated.id)
        return null
    }

    fun delete(game: Game) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { repo.delete(game) }
            if (ok) {
                games = games.filter { it.id != game.id }
                setFavorites(favorites - game.id)
                message = "\u00AB${game.name}\u00BB borrado"
            } else {
                message = "No se pudo borrar"
            }
        }
    }
}
