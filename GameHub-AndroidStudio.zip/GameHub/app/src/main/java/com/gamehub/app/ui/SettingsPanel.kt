package com.gamehub.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gamehub.app.GameHubViewModel
import com.gamehub.app.formatSize

@Composable
fun SettingsOverlay(vm: GameHubViewModel, onClose: () -> Unit) {
    val g = LocalGlass.current
    val ink = g.ink
    val s = vm.settings

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)).consumeClicks(onClose)) {
        Column(
            Modifier.align(Alignment.BottomCenter)
                .padding(horizontal = 10.dp)
                .navigationBarsPadding()
                .padding(bottom = 10.dp)
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .glass(RoundedCornerShape(36.dp))
                .consumeClicks()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AJUSTES", color = ink, fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(ink.copy(alpha = 0.1f)).consumeClicks(onClose),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, "Cerrar", tint = ink) }
            }

            // ---------- Apariencia ----------
            SectionTitle("Apariencia")
            SwitchRow("Liquid glass", "Cristal con blur din\u00E1mico. Apagado = superficies s\u00F3lidas.", s.liquidGlass) { v ->
                vm.updateSettings { it.copy(liquidGlass = v) }
            }
            Text("Intensidad del blur: ${s.blurDp.toInt()}", color = ink.copy(alpha = if (s.liquidGlass) 1f else 0.4f), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Slider(
                value = s.blurDp, valueRange = 4f..48f, enabled = s.liquidGlass,
                onValueChange = { v -> vm.updateSettings { it.copy(blurDp = v) } },
                colors = SliderDefaults.colors(thumbColor = g.accent, activeTrackColor = g.accent),
            )
            LabelText("Tema")
            Segmented(listOf("Sistema", "Claro", "Oscuro"), s.theme) { i -> vm.updateSettings { it.copy(theme = i) } }
            Spacer(Modifier.height(14.dp))
            LabelText("Color de acento")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accents.forEachIndexed { i, c ->
                    val sel = i == s.accentIndex
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(c)
                            .border(if (sel) 3.dp else 0.dp, if (sel) ink else Color.Transparent, CircleShape)
                            .consumeClicks { vm.updateSettings { it.copy(accentIndex = i) } },
                    )
                }
            }

            // ---------- Biblioteca ----------
            SectionTitle("Biblioteca")
            LabelText("Columnas")
            Segmented(listOf("1", "2", "3"), (s.columns - 1).coerceIn(0, 2)) { i -> vm.updateSettings { it.copy(columns = i + 1) } }
            Spacer(Modifier.height(14.dp))
            LabelText("Ordenar por")
            Segmented(listOf("Nombre", "Recientes", "Peso"), s.sort) { i -> vm.updateSettings { it.copy(sort = i) } }
            Spacer(Modifier.height(6.dp))
            SwitchRow("Mostrar peso en las tarjetas", null, s.showSize) { v -> vm.updateSettings { it.copy(showSize = v) } }

            // ---------- Juego ----------
            SectionTitle("Al jugar")
            LabelText("Orientaci\u00F3n")
            Segmented(listOf("Auto", "Horizontal", "Vertical"), s.orientation) { i -> vm.updateSettings { it.copy(orientation = i) } }
            Spacer(Modifier.height(6.dp))
            SwitchRow("Pantalla completa inmersiva", "Oculta barra de estado y navegaci\u00F3n.", s.immersive) { v -> vm.updateSettings { it.copy(immersive = v) } }
            SwitchRow("Mantener pantalla encendida", null, s.keepScreenOn) { v -> vm.updateSettings { it.copy(keepScreenOn = v) } }

            // ---------- Info ----------
            SectionTitle("Almacenamiento")
            Text(
                "${vm.games.size} juegos \u00B7 ${formatSize(vm.games.sumOf { it.sizeBytes })}",
                color = ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            )
            Text("Carpeta: files/juegos/", color = ink.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.clip(CircleShape).background(g.accent.copy(alpha = 0.2f))
                    .consumeClicks { vm.refresh() }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            ) { Text("Recargar biblioteca", color = g.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            Spacer(Modifier.height(18.dp))
            Text("GameHub 1.0", color = ink.copy(alpha = 0.4f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    val g = LocalGlass.current
    Spacer(Modifier.height(22.dp))
    Text(text.uppercase(), color = g.accent, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun LabelText(text: String) {
    val g = LocalGlass.current
    Text(text, color = g.ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, color = g.ink.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = g.accent, checkedThumbColor = Color.White),
        )
    }
}
