package com.gamehub.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipInputStream

class ImportException(message: String) : Exception(message)

class GameRepository(private val context: Context) {

    /** /data/data/<app>/files/juegos/ */
    val root: File
        get() = File(context.filesDir, "juegos").also { it.mkdirs() }

    // Orden de busqueda de portada pedido: cover.png, cover.jpg, icon.png, icon.jpg, thumbnail.png
    private val coverNames = listOf("cover.png", "cover.jpg", "icon.png", "icon.jpg", "thumbnail.png")

    fun list(): List<Game> {
        val dirs = root.listFiles() ?: return emptyList()
        dirs.filter { it.name.startsWith(".tmp_") }.forEach { it.deleteRecursively() }
        return dirs.filter { it.isDirectory && !it.name.startsWith(".") }.map { toGame(it) }
    }

    fun toGame(dir: File): Game {
        val idFile = File(dir, ".gamehub_id")
        val installed = idFile.lastModified().takeIf { it > 0 } ?: dir.lastModified()
        return Game(
            id = dir.name,
            name = dir.name,
            dir = dir,
            cover = findCover(dir),
            sizeBytes = dirSize(dir),
            installedAt = installed,
        )
    }

    private fun findCover(dir: File): File? {
        val byLower = dir.listFiles()?.filter { it.isFile }?.associateBy { it.name.lowercase() } ?: return null
        for (n in coverNames) byLower[n]?.let { return it }
        return null
    }

    private fun dirSize(dir: File): Long =
        dir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Id estable por juego (para aislar localStorage entre juegos, aunque se renombre). */
    fun gameKey(dir: File): String {
        val f = File(dir, ".gamehub_id")
        if (f.isFile) {
            val t = runCatching { f.readText().trim() }.getOrDefault("")
            if (t.isNotEmpty()) return t
        }
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        runCatching { f.writeText(id) }
        return id
    }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun sanitize(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "").trim().trimStart('.').trim().take(60)

    private fun uniqueName(base: String): String {
        var name = base
        var i = 2
        while (File(root, name).exists()) { name = "$base-$i"; i++ }
        return name
    }

    /** Descomprime con java.util.zip en files/juegos/<nombre>/ */
    fun importZip(uri: Uri): Game {
        val raw = displayName(uri) ?: "juego"
        val base = sanitize(raw.replace(Regex("\\.zip$", RegexOption.IGNORE_CASE), "")).ifEmpty { "juego" }
        val tmp = File(root, ".tmp_${System.nanoTime()}")
        try {
            tmp.mkdirs()
            val tmpCanon = tmp.canonicalPath
            var count = 0
            val input = context.contentResolver.openInputStream(uri)
                ?: throw ImportException("No se pudo abrir el archivo")
            input.use { raw0 ->
                ZipInputStream(BufferedInputStream(raw0)).use { zis ->
                    val buf = ByteArray(64 * 1024)
                    var e = zis.nextEntry
                    while (e != null) {
                        val name = e.name.replace('\\', '/')
                        if (!name.startsWith("__MACOSX/") && !name.endsWith(".DS_Store")) {
                            val out = File(tmp, name)
                            val canon = out.canonicalPath
                            if (canon != tmpCanon) {
                                if (!canon.startsWith(tmpCanon + File.separator)) {
                                    throw ImportException("Zip no valido (ruta insegura)")
                                }
                                if (e.isDirectory) {
                                    out.mkdirs()
                                } else {
                                    out.parentFile?.mkdirs()
                                    FileOutputStream(out).use { os ->
                                        while (true) {
                                            val n = zis.read(buf)
                                            if (n == -1) break
                                            os.write(buf, 0, n)
                                        }
                                    }
                                    count++
                                }
                            }
                        }
                        zis.closeEntry()
                        e = zis.nextEntry
                    }
                }
            }
            if (count == 0) throw ImportException("El archivo no es un .zip valido o esta vacio")

            // index.html debe estar en la raiz (se tolera una unica carpeta contenedora)
            var gameRoot = tmp
            if (!File(tmp, "index.html").isFile) {
                val kids = tmp.listFiles()?.toList() ?: emptyList()
                val onlyDir = kids.singleOrNull()?.takeIf { it.isDirectory && File(it, "index.html").isFile }
                if (onlyDir != null) gameRoot = onlyDir
                else throw ImportException("Este zip no tiene index.html")
            }

            val dest = File(root, uniqueName(base))
            if (!gameRoot.renameTo(dest)) throw ImportException("No se pudo guardar el juego")
            if (gameRoot != tmp) tmp.deleteRecursively()
            gameKey(dest)
            return toGame(dest)
        } catch (t: Throwable) {
            tmp.deleteRecursively()
            throw if (t is ImportException) t else ImportException(t.message ?: "Error al importar")
        }
    }

    fun rename(game: Game, raw: String): Result<Game> = runCatching {
        val name = sanitize(raw)
        if (name.isEmpty()) throw ImportException("Nombre no valido")
        if (name == game.name) return@runCatching game
        val clash = root.listFiles()?.any { it.name.equals(name, true) && it.name != game.name } == true
        if (clash) throw ImportException("Ya existe un juego con ese nombre")
        val dest = File(root, name)
        if (!game.dir.renameTo(dest)) throw ImportException("No se pudo renombrar")
        game.copy(
            id = name, name = name, dir = dest,
            cover = game.cover?.let { File(dest, it.name) },
        )
    }

    fun delete(game: Game): Boolean = game.dir.deleteRecursively()
}
