package com.gamehub.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.hazeChild

val Accents = listOf(
    Color(0xFF3D7BFF), Color(0xFFFF4D8D), Color(0xFF8B5CF6),
    Color(0xFF22C55E), Color(0xFFFF9F0A), Color(0xFF06B6D4),
)
val AccentNames = listOf("Azul", "Rosa", "Violeta", "Verde", "Naranja", "Cian")

data class GlassSpec(
    val enabled: Boolean,
    val blur: Dp,
    val dark: Boolean,
    val accent: Color,
    val haze: HazeState,
)

val LocalGlass = staticCompositionLocalOf<GlassSpec> { error("GlassSpec no provisto") }

val GlassSpec.ink: Color get() = if (dark) Color.White else Color(0xFF111114)

@Composable
fun resolveDark(theme: Int): Boolean = when (theme) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun GameHubTheme(dark: Boolean, accent: Color, content: @Composable () -> Unit) {
    val scheme = if (dark) {
        darkColorScheme(primary = accent, background = Color.Black, surface = Color(0xFF1C1C1E))
    } else {
        lightColorScheme(primary = accent, background = Color(0xFFF2F2F7), surface = Color.White)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Modifier.consumeClicks(onClick: () -> Unit = {}): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

/**
 * Liquid glass: blur REAL del contenido que hay detras (se actualiza en vivo al hacer scroll),
 * relleno translucido, brillo superior y borde con degradado (efecto de canto de cristal).
 * Con liquid glass desactivado se usa una superficie solida plana.
 */
@Composable
fun Modifier.glass(
    shape: Shape,
    tint: Color = Color.Unspecified,
    tint2: Color = Color.Unspecified,
    strength: Float = 1f,
): Modifier {
    val g = LocalGlass.current
    val hasTint = tint != Color.Unspecified
    return if (!g.enabled) {
        val solid = when {
            hasTint && strength >= 1f -> tint
            g.dark -> Color(0xFF242427)
            else -> Color.White
        }
        val edge = if (g.dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.08f)
        this.clip(shape).background(solid).border(1.dp, edge, shape)
    } else {
        val rim = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (g.dark) 0.55f else 0.95f),
                Color.White.copy(alpha = if (g.dark) 0.06f else 0.20f),
                Color.White.copy(alpha = if (g.dark) 0.30f else 0.70f),
            )
        )
        val fill: Brush = if (hasTint) {
            val t2 = if (tint2 != Color.Unspecified) tint2 else tint
            Brush.linearGradient(listOf(tint.copy(alpha = 0.60f * strength), t2.copy(alpha = 0.35f * strength)))
        } else {
            SolidColor(Color.White.copy(alpha = if (g.dark) 0.09f else 0.50f))
        }
        val gloss = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent))
        this.clip(shape)
            .hazeChild(
                state = g.haze,
                shape = shape,
                style = HazeStyle(tints = emptyList(), blurRadius = g.blur, noiseFactor = 0f),
            )
            .background(fill)
            .background(gloss)
            .border(1.dp, rim, shape)
    }
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    size: Dp = 52.dp,
    tint: Color = Color.Unspecified,
) {
    val g = LocalGlass.current
    val iconColor = if (tint != Color.Unspecified) Color.White else g.ink
    Box(
        Modifier.size(size).glass(CircleShape, tint).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = desc, tint = iconColor, modifier = Modifier.size(size * 0.48f))
    }
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val g = LocalGlass.current
    Row(
        Modifier.fillMaxWidth().clip(CircleShape).background(g.ink.copy(alpha = 0.08f)).padding(3.dp)
    ) {
        options.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(CircleShape)
                    .background(if (sel) g.accent else Color.Transparent)
                    .consumeClicks { onSelect(i) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, maxLines = 1, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = if (sel) Color.White else g.ink,
                )
            }
        }
    }
}
