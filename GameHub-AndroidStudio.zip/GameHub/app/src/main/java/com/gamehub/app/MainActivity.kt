package com.gamehub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import com.gamehub.app.ui.GameHubScreen
import com.gamehub.app.ui.resolveDark

class MainActivity : ComponentActivity() {
    private val vm: GameHubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            vm.importUris(uris)
        }

        setContent {
            val dark = resolveDark(vm.settings.theme)
            DisposableEffect(dark) {
                val t = android.graphics.Color.TRANSPARENT
                val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            GameHubScreen(
                vm = vm,
                onPlay = { game -> startActivity(GameActivity.intent(this@MainActivity, game.dir.name)) },
                onImport = { picker.launch(arrayOf("*/*")) },
            )
        }
    }
}
