# GameHub (Android, Kotlin + Jetpack Compose)

## Compilar el APK
1. Instala Android Studio Ladybug (2024.2.1) o mas nuevo (JDK 17 incluido).
2. File > Open > selecciona esta carpeta "GameHub". Espera el Gradle Sync (necesita internet la primera vez).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK queda en app/build/outputs/apk/debug/app-debug.apk. Copialo al telefono e instalalo.

Android minimo: 12 (API 31).

## Formato de cada juego .zip
- index.html en la raiz (se tolera una unica carpeta contenedora).
- Portada en la raiz, se busca en este orden: cover.png, cover.jpg, icon.png, icon.jpg, thumbnail.png
- Se instala en files/juegos/<nombre-del-zip>/
